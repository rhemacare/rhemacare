rootProject.name = "Speech2text"
include(":app")

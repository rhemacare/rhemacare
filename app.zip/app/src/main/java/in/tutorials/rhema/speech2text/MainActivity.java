package in.tutorials.rhema.speech2text;

import android.app.Activity;

public class MainActivity extends Activity {
}
